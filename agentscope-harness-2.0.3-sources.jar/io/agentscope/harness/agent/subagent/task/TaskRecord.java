/*
 * Copyright 2024-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.agentscope.harness.agent.subagent.task;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.agentscope.harness.agent.subagent.protocol.RemotePendingConfirm;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Persistent metadata for a background subagent task, stored as JSON in the workspace under
 * {@code agents/<parentAgentId>/tasks/<parentSessionId>.json}.
 *
 * <p>This is the authoritative truth source for task state. In-memory {@link BackgroundTask}
 * handles are a local performance overlay; {@code TaskRecord} survives across JVM restarts and
 * request migrations in distributed deployments.
 *
 * <p>All fields use Jackson for JSON serialization. Unknown fields are silently ignored to
 * allow forward-compatible schema evolution.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaskRecord {

    private String taskId;
    private String subAgentId;
    private String parentAgentId;
    private String parentSessionId;
    private String subSessionId;
    private TaskStatus status;
    private String result;
    private String errorMessage;
    private boolean cancelRequested;
    private Instant createdAt;
    private Instant lastCheckedAt;
    private Instant lastUpdatedAt;

    /**
     * When this terminal-state task's result was pushed back to the parent agent as a synthetic
     * {@code <system-reminder>} message, or {@code null} when not yet delivered. Used by
     * {@link io.agentscope.harness.agent.middleware.SubagentsMiddleware} to avoid re-delivering
     * the same completion every reasoning round.
     */
    private Instant deliveredAt;

    /** When {@code "agent-protocol"}, this task is driven by {@link AgentProtocolTaskClient}. */
    private String transportType;

    private String remoteBaseUrl;

    private Map<String, String> remoteHeaders;

    /**
     * When {@code true}, the remote (or local) agent is paused waiting for user tool confirmation.
     * Status remains {@link TaskStatus#RUNNING} so barriers keep waiting.
     */
    private boolean awaitingConfirm;

    private List<RemotePendingConfirm> pendingConfirms;

    /** Last remote event sequence observed by the parent (for SSE resume). */
    private long lastEventSeq;

    public TaskRecord() {}

    public TaskRecord(
            String taskId,
            String subAgentId,
            String parentAgentId,
            String parentSessionId,
            String subSessionId) {
        this.taskId = taskId;
        this.subAgentId = subAgentId;
        this.parentAgentId = parentAgentId;
        this.parentSessionId = parentSessionId;
        this.subSessionId = subSessionId;
        this.status = TaskStatus.PENDING;
        this.cancelRequested = false;
        Instant now = Instant.now();
        this.createdAt = now;
        this.lastCheckedAt = now;
        this.lastUpdatedAt = now;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getSubAgentId() {
        return subAgentId;
    }

    public void setSubAgentId(String subAgentId) {
        this.subAgentId = subAgentId;
    }

    public String getParentAgentId() {
        return parentAgentId;
    }

    public void setParentAgentId(String parentAgentId) {
        this.parentAgentId = parentAgentId;
    }

    public String getParentSessionId() {
        return parentSessionId;
    }

    public void setParentSessionId(String parentSessionId) {
        this.parentSessionId = parentSessionId;
    }

    public String getSubSessionId() {
        return subSessionId;
    }

    public void setSubSessionId(String subSessionId) {
        this.subSessionId = subSessionId;
    }

    public TaskStatus getStatus() {
        return status;
    }

    public void setStatus(TaskStatus status) {
        this.status = status;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public boolean isCancelRequested() {
        return cancelRequested;
    }

    public void setCancelRequested(boolean cancelRequested) {
        this.cancelRequested = cancelRequested;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getLastCheckedAt() {
        return lastCheckedAt;
    }

    public void setLastCheckedAt(Instant lastCheckedAt) {
        this.lastCheckedAt = lastCheckedAt;
    }

    public Instant getLastUpdatedAt() {
        return lastUpdatedAt;
    }

    public void setLastUpdatedAt(Instant lastUpdatedAt) {
        this.lastUpdatedAt = lastUpdatedAt;
    }

    /** Convenience: update lastUpdatedAt to now. */
    public void touch() {
        this.lastUpdatedAt = Instant.now();
    }

    /** Convenience: update lastCheckedAt to now. */
    public void touchChecked() {
        this.lastCheckedAt = Instant.now();
    }

    public Instant getDeliveredAt() {
        return deliveredAt;
    }

    public void setDeliveredAt(Instant deliveredAt) {
        this.deliveredAt = deliveredAt;
    }

    /** Whether this task's completion has been pushed back to the parent agent. */
    public boolean isDelivered() {
        return deliveredAt != null;
    }

    public String getTransportType() {
        return transportType;
    }

    public void setTransportType(String transportType) {
        this.transportType = transportType;
    }

    public String getRemoteBaseUrl() {
        return remoteBaseUrl;
    }

    public void setRemoteBaseUrl(String remoteBaseUrl) {
        this.remoteBaseUrl = remoteBaseUrl;
    }

    public Map<String, String> getRemoteHeaders() {
        return remoteHeaders;
    }

    public void setRemoteHeaders(Map<String, String> remoteHeaders) {
        this.remoteHeaders =
                remoteHeaders == null || remoteHeaders.isEmpty()
                        ? null
                        : Collections.unmodifiableMap(Map.copyOf(remoteHeaders));
    }

    /** Whether this task is executed via the HTTP task protocol. */
    public boolean isAgentProtocolTransport() {
        return transportType != null && "agent-protocol".equalsIgnoreCase(transportType);
    }

    public boolean isAwaitingConfirm() {
        return awaitingConfirm;
    }

    public void setAwaitingConfirm(boolean awaitingConfirm) {
        this.awaitingConfirm = awaitingConfirm;
    }

    public List<RemotePendingConfirm> getPendingConfirms() {
        return pendingConfirms;
    }

    public void setPendingConfirms(List<RemotePendingConfirm> pendingConfirms) {
        this.pendingConfirms =
                pendingConfirms == null || pendingConfirms.isEmpty()
                        ? null
                        : List.copyOf(pendingConfirms);
    }

    public long getLastEventSeq() {
        return lastEventSeq;
    }

    public void setLastEventSeq(long lastEventSeq) {
        this.lastEventSeq = lastEventSeq;
    }
}
